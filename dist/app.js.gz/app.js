(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app"],{

/***/ "./src/index.jsx":
/*!***********************!*\
  !*** ./src/index.jsx ***!
  \***********************/
/*! exports provided: default */
/*! ModuleConcatenation bailout: Module is an entry point */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_jsx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/jsx */ "./node_modules/@babel/runtime/helpers/jsx.js");
/* harmony import */ var _babel_runtime_helpers_jsx__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_jsx__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/inherits */ "./node_modules/@babel/runtime/helpers/inherits.js");
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-dom */ "./node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var whs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! whs */ "./node_modules/whs/build/whs.module.js");










var SceneModule = __webpack_require__(/*! whs */ "./node_modules/whs/build/whs.module.js");

var DefineModule = __webpack_require__(/*! whs */ "./node_modules/whs/build/whs.module.js");

var ElementModule = __webpack_require__(/*! whs */ "./node_modules/whs/build/whs.module.js");

var OrbitControlsModule = __webpack_require__(/*! whs */ "./node_modules/whs/build/whs.module.js");

var PerspectiveCamera = __webpack_require__(/*! whs */ "./node_modules/whs/build/whs.module.js");

var Plane = __webpack_require__(/*! whs */ "./node_modules/whs/build/whs.module.js");

var RenderingModule = __webpack_require__(/*! whs */ "./node_modules/whs/build/whs.module.js");

var App = whs__WEBPACK_IMPORTED_MODULE_8__["App"]();

var _ref =
/*#__PURE__*/
_babel_runtime_helpers_jsx__WEBPACK_IMPORTED_MODULE_0___default()("div", {
  className: "div"
}, void 0, _babel_runtime_helpers_jsx__WEBPACK_IMPORTED_MODULE_0___default()("h1", {}, void 0, "hello"));

var Application =
/*#__PURE__*/
function (_React$Component) {
  _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_5___default()(Application, _React$Component);

  function Application() {
    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, Application);

    return _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default()(this, _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4___default()(Application).apply(this, arguments));
  }

  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2___default()(Application, [{
    key: "render",
    value: function render() {
      return _ref;
    }
  }]);

  return Application;
}(react__WEBPACK_IMPORTED_MODULE_6___default.a.Component);

/* harmony default export */ __webpack_exports__["default"] = (react_dom__WEBPACK_IMPORTED_MODULE_7___default.a.render(_babel_runtime_helpers_jsx__WEBPACK_IMPORTED_MODULE_0___default()(Application, {}), document.getElementById('app')));

/***/ })

},[["./src/index.jsx","runtime","vendors~app"]]]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvaW5kZXguanN4Il0sIm5hbWVzIjpbIlNjZW5lTW9kdWxlIiwicmVxdWlyZSIsIkRlZmluZU1vZHVsZSIsIkVsZW1lbnRNb2R1bGUiLCJPcmJpdENvbnRyb2xzTW9kdWxlIiwiUGVyc3BlY3RpdmVDYW1lcmEiLCJQbGFuZSIsIlJlbmRlcmluZ01vZHVsZSIsIkFwcCIsIldIUyIsIkFwcGxpY2F0aW9uIiwiUmVhY3QiLCJDb21wb25lbnQiLCJSZWFjdERPTSIsInJlbmRlciIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBOztBQUVBLElBQU1BLFdBQVcsR0FBR0MsbUJBQU8sQ0FBQyxtREFBRCxDQUEzQjs7QUFDQSxJQUFNQyxZQUFZLEdBQUdELG1CQUFPLENBQUMsbURBQUQsQ0FBNUI7O0FBQ0EsSUFBTUUsYUFBYSxHQUFHRixtQkFBTyxDQUFDLG1EQUFELENBQTdCOztBQUNBLElBQU1HLG1CQUFtQixHQUFHSCxtQkFBTyxDQUFDLG1EQUFELENBQW5DOztBQUNBLElBQU1JLGlCQUFpQixHQUFHSixtQkFBTyxDQUFDLG1EQUFELENBQWpDOztBQUNBLElBQU1LLEtBQUssR0FBR0wsbUJBQU8sQ0FBQyxtREFBRCxDQUFyQjs7QUFDQSxJQUFNTSxlQUFlLEdBQUdOLG1CQUFPLENBQUMsbURBQUQsQ0FBL0I7O0FBRUEsSUFBTU8sR0FBRyxHQUFHQyx1Q0FBQSxFQUFaOzs7O0FBTU07QUFBSyxXQUFTLEVBQUM7QUFBZixXQUNFLDRGQURGLEM7O0lBSEFDLFc7Ozs7Ozs7Ozs7Ozs7NkJBQ0s7QUFDUDtBQUtEOzs7O0VBUHVCQyw0Q0FBSyxDQUFDQyxTOztBQVVqQkMsK0dBQVEsQ0FBQ0MsTUFBVCxDQUFnQixrRUFBQyxXQUFELEtBQWhCLEVBQWlDQyxRQUFRLENBQUNDLGNBQVQsQ0FBd0IsS0FBeEIsQ0FBakMsQ0FBZixFIiwiZmlsZSI6ImFwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20nXG5pbXBvcnQgKiBhcyBXSFMgZnJvbSAnd2hzJ1xuXG5jb25zdCBTY2VuZU1vZHVsZSA9IHJlcXVpcmUoJ3docycpXG5jb25zdCBEZWZpbmVNb2R1bGUgPSByZXF1aXJlKCd3aHMnKVxuY29uc3QgRWxlbWVudE1vZHVsZSA9IHJlcXVpcmUoJ3docycpXG5jb25zdCBPcmJpdENvbnRyb2xzTW9kdWxlID0gcmVxdWlyZSgnd2hzJylcbmNvbnN0IFBlcnNwZWN0aXZlQ2FtZXJhID0gcmVxdWlyZSgnd2hzJylcbmNvbnN0IFBsYW5lID0gcmVxdWlyZSgnd2hzJylcbmNvbnN0IFJlbmRlcmluZ01vZHVsZSA9IHJlcXVpcmUoJ3docycpXG5cbmNvbnN0IEFwcCA9IFdIUy5BcHAoKVxuXG5cbmNsYXNzIEFwcGxpY2F0aW9uIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50IHtcbiAgcmVuZGVyKCkge1xuICAgIHJldHVybihcbiAgICAgIDxkaXYgY2xhc3NOYW1lPSdkaXYnPlxuICAgICAgICA8aDE+aGVsbG88L2gxPlxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IFJlYWN0RE9NLnJlbmRlcig8QXBwbGljYXRpb24gLz4sIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdhcHAnKSlcbiJdLCJzb3VyY2VSb290IjoiIn0=